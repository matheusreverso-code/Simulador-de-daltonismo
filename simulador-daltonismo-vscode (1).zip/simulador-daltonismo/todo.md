# Adaptação para GitHub

## Objetivo

Deixar o simulador de daltonismo independente do ambiente Manus, pronto para versionamento em um repositório Git e publicação pelo GitHub Pages.

## Tarefas

- [x] Remover referências a imagens privadas do ambiente atual.
- [x] Substituir o logo remoto por SVG embutido e favicon local.
- [x] Substituir o fundo de hero remoto por uma composição CSS.
- [x] Configurar o Vite com `VITE_BASE_PATH` para GitHub Pages.
- [x] Criar README.md com instalação, uso, build, deploy e autoria.
- [x] Adicionar workflow do GitHub Actions para publicar o diretório `dist`.
- [x] Revisar `.gitignore` para ignorar artefatos de build e segredos.
- [x] Validar TypeScript, build e preview responsivo.
- [ ] Salvar checkpoint final e entregar a versão pronta para GitHub.

## Decisões técnicas

O projeto continuará usando React, TypeScript, Vite e Tailwind CSS, todos já presentes no scaffold. O simulador é client-side e não depende de backend, banco de dados, APIs ou login. A publicação recomendada será feita pelo GitHub Pages usando GitHub Actions. O diretório `server/` permanecerá no scaffold original por compatibilidade, mas não participa do build estático do GitHub Pages.

## Autoria

A autoria será indicada no README e no rodapé como projeto educacional do autor do repositório, desenvolvido com suporte de Manus AI.

## Referências

[1] [National Eye Institute — Types of Color Blindness](https://www.nei.gov/espanol/informacion-sobre-la-salud-ocular/enfermedades-y-afecciones-de-los-ojos/daltonismo/tipos-de-daltonismo)

[2] [DaltonLens — Accurate SVG filters for color blindness simulation](https://daltonlens.org/cvd-simulation-svg-filters/)

[3] [GitHub Docs — Configuring a publishing source for GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

[4] [GitHub Docs — Using custom GitHub Actions workflows to publish your site](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-github-actions-workflows-to-publish-your-site)

## Style Decisions

Manter a direção visual Elegância Acessível, com azul-acinzentado, coral, verde-musgo e ouro; Poppins para títulos; Inter para corpo; contraste baseado em luminância; e componentes que usem formas, nomes e texto além da cor.

**Autor:** Manus AI
**Data:** 2026-08-17
**Status:** Em adaptação para GitHub
