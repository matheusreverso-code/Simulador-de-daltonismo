# Simulador de Daltonismo

Aplicação web educativa e responsiva que mostra uma paleta de cores normal e simula como ela pode ser percebida em diferentes tipos de deficiência visual cromática. O projeto foi desenvolvido com React, TypeScript, Vite, Tailwind CSS e filtros SVG aplicados no navegador.

> **Autoria:** projeto educacional criado pelo autor deste repositório, com suporte de desenvolvimento do Manus AI.

## Funcionalidades

A interface apresenta nove estados de visualização: visão normal, protanopia, deuteranopia, tritanopia, acromatopsia, protanomalia, deuteranomalia, tritanomalia e acromatomalia. Cada estado possui uma descrição curta e um botão **Clique e Veja** que aplica a transformação correspondente à paleta de oito cores.

A simulação é feita no cliente por meio de filtros SVG. Ela é uma representação educativa e não substitui avaliação oftalmológica, diagnóstico ou experiência individual de uma pessoa com daltonismo.

## Tecnologias

| Camada | Tecnologia |
| --- | --- |
| Interface | React 19 + TypeScript |
| Build | Vite |
| Estilos | Tailwind CSS 4 + CSS customizado |
| Ícones | Lucide React |
| Simulação | SVG `feColorMatrix` |
| Publicação | GitHub Pages via GitHub Actions |

## Requisitos

É necessário ter Node.js 20 ou superior e pnpm 10 instalado. Também é possível usar npm, mas os comandos abaixo usam pnpm porque o repositório inclui `pnpm-lock.yaml`.

## Executar localmente

```bash
pnpm install
pnpm dev
```

Depois, abra o endereço exibido pelo Vite, normalmente `http://localhost:3000`.

Para validar tipos e gerar o build estático:

```bash
pnpm check
pnpm build
pnpm preview
```

O build final será criado em `dist/`. Essa pasta é gerada automaticamente e não deve ser versionada.

## Subir para o GitHub

Crie um repositório vazio no GitHub, sem adicionar README ou `.gitignore`, e execute os comandos abaixo na pasta deste projeto. Substitua `SEU_USUARIO` pelo seu usuário e `NOME_DO_REPOSITORIO` pelo nome do repositório criado.

```bash
git init
git add .
git commit -m "feat: criar simulador de daltonismo"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/NOME_DO_REPOSITORIO.git
git push -u origin main
```

Depois do primeiro push, a aba **Actions** exibirá o workflow de publicação. O arquivo `.github/workflows/deploy-pages.yml` já está incluído no projeto.

## Publicar pelo GitHub Pages

O workflow configura automaticamente o caminho base com o nome do repositório, gera o build e publica `dist/` no GitHub Pages. No GitHub, abra **Settings → Pages**, confirme que a fonte está configurada como **GitHub Actions** e aguarde a execução do workflow.

Em um repositório chamado `simulador-daltonismo`, a URL normalmente será:

```text
https://SEU_USUARIO.github.io/simulador-daltonismo/
```

Se o projeto for publicado em um domínio próprio ou em um repositório de usuário, o Vite pode ser executado com outro caminho base:

```bash
VITE_BASE_PATH=/ pnpm build
```

## Estrutura principal

```text
client/
  public/
    favicon.svg
  src/
    components/
    pages/Home.tsx
    App.tsx
    index.css
    main.tsx
.github/
  workflows/deploy-pages.yml
README.md
package.json
pnpm-lock.yaml
vite.config.ts
```

O projeto não depende de imagens privadas, APIs, banco de dados ou backend para funcionar. O logo é um SVG embutido e o fundo visual do hero é construído com CSS, permitindo que o repositório seja clonado e executado de forma independente.

## Autoria e licença

O conteúdo textual e as simulações devem ser utilizados para educação e conscientização. Adapte o campo de autoria do README, do rodapé e dos metadados conforme a pessoa ou equipe responsável pelo repositório. O projeto está marcado com licença MIT no `package.json`; se necessário, adicione um arquivo `LICENSE` com o texto oficial da licença escolhido pelo autor.

## Referências

[1] [National Eye Institute — Types of Color Blindness](https://www.nei.gov/espanol/informacion-sobre-la-salud-ocular/enfermedades-y-afecciones-de-los-ojos/daltonismo/tipos-de-daltonismo)

[2] [DaltonLens — Accurate SVG filters for color blindness simulation](https://daltonlens.org/cvd-simulation-svg-filters/)

[3] [GitHub Docs — Configuring a publishing source for GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

[4] [GitHub Docs — Using custom GitHub Actions workflows to publish your site](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-github-actions-workflows-to-publish-your-site)
