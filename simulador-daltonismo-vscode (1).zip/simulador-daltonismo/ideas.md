# Simulador de Daltonismo - Design Philosophy

## Pesquisa sobre Daltonismo

### Tipos de Daltonismo

1. **Protanopia** (Deficiência de Vermelho)
   - Afeta ~1% dos homens
   - Dificuldade em diferenciar vermelho, verde e amarelo
   - Cores vermelhas aparecem como marrom/preto
   - Verdes aparecem como amarelados

2. **Deuteranopia** (Deficiência de Verde)
   - Afeta ~1% dos homens
   - Similar à Protanopia, mas com padrão ligeiramente diferente
   - Vermelhos e verdes aparecem como amarelados/marrons
   - Azuis e amarelos são distinguíveis

3. **Tritanopia** (Deficiência de Azul)
   - Muito rara (~0.001% da população)
   - Afeta igualmente homens e mulheres
   - Azuis aparecem como rosa/vermelhos
   - Amarelos aparecem como rosa/roxos

4. **Acromatopsia** (Monocromacia)
   - Extremamente rara (~0.00003% da população)
   - Visão completamente em escala de cinza
   - Sensibilidade aumentada à luz
   - Acuidade visual reduzida

5. **Protanomalia** (Anomalia de Vermelho - Leve)
   - Forma leve de Protanopia
   - Cores vermelhas aparecem mais esverdeadas

6. **Deuteranomalia** (Anomalia de Verde - Leve)
   - Forma leve de Deuteranopia
   - Cores verdes aparecem mais avermelhadas

7. **Tritanomalia** (Anomalia de Azul - Leve)
   - Forma leve de Tritanopia
   - Cores azuis e amarelas ligeiramente alteradas

8. **Achromatomalia** (Monocromacia Incompleta)
   - Forma leve de Acromatopsia
   - Visão em escala de cinza com cores muito dessaturadas

---

## Abordagens de Design

### Abordagem 1: Educacional Minimalista
**Tema:** Clareza Científica
**Probabilidade:** 0.08
Foco em tipografia clara, paleta neutra com destaque em cores de teste. Layout linear e informativo, sem distrações.

### Abordagem 2: Interativo e Vibrante
**Tema:** Exploração Lúdica
**Probabilidade:** 0.06
Cores vibrantes, transições suaves, cards interativas. Foco em descoberta e experimentação através de interações.

### Abordagem 3: Elegância Acessível
**Tema:** Design Inclusivo Premium
**Probabilidade:** 0.07
Paleta sofisticada com tons naturais, tipografia elegante, espaçamento generoso. Foco em inclusão e beleza.

---

## Design Escolhido: Elegância Acessível

### Design Movement
**Bauhaus Moderno com Acessibilidade em Primeiro Plano**
Combina princípios de design limpo e funcional com foco em inclusão visual. Inspirado em design systems contemporâneos que priorizam acessibilidade.

### Core Principles
1. **Clareza sem Sacrifício Estético** - Informação legível e bela simultaneamente
2. **Inclusão Ativa** - Cada elemento pensado para pessoas com daltonismo
3. **Espaçamento Generoso** - Respira e permite foco
4. **Contraste Inteligente** - Não apenas cores, mas formas e texturas

### Color Philosophy
**Paleta Baseada em Luminância e Contraste, Não Apenas em Matiz**

- **Primária:** Azul-acinzentado profundo (`#2C3E50`) - Neutro, acessível
- **Secundária:** Coral suave (`#E8756B`) - Quente, mas com luminância moderada
- **Terciária:** Verde-musgo (`#6B8E7F`) - Natureza, calma
- **Neutra:** Cinza-claro (`#F5F7FA`) - Fundo limpo
- **Destaque:** Ouro suave (`#D4A574`) - Elegância, guia visual

**Raciocínio:** Evita combinações vermelho-verde puras. Usa luminância para criar hierarquia. Tons naturais transmitem confiança científica.

### Layout Paradigm
**Grid Assimétrico com Fluxo Vertical Intencional**

- Hero section com tipografia grande e espaçamento
- Cards em grid responsivo (1 col mobile, 2 cols tablet, 3 cols desktop)
- Paletas de cores em seções horizontais scrolláveis
- Botões de ação com ícones e texto
- Rodapé com informações educacionais

### Signature Elements
1. **Paletas de Cores Horizontais** - Faixas de cores que mudam com filtros
2. **Cards com Sombra Suave** - Profundidade sem dramaticidade
3. **Tipografia em Duas Camadas** - Display bold + body regular

### Interaction Philosophy
- **Transições Suaves:** 300ms ease-out para mudanças de filtro
- **Feedback Visual:** Botões escurecem ao clicar, paletas mudam com animação
- **Acessibilidade:** Teclado navegável, focus rings visíveis, ARIA labels

### Animation
- Filtros de cor aplicados com transição CSS de 400ms
- Entrada de cards com stagger de 50ms
- Hover em cards: elevação suave (transform: translateY(-2px))
- Mudança de filtro: fade suave da paleta

### Typography System
- **Display:** Poppins Bold 700 (32px-48px) - Títulos principais
- **Heading:** Poppins SemiBold 600 (24px-28px) - Seções
- **Body:** Inter Regular 400 (16px) - Texto principal
- **Small:** Inter Regular 400 (14px) - Descrições

**Hierarquia:** Display > Heading > Body > Small, com espaçamento proporcional

### Brand Essence
**"Enxergar o mundo como ele realmente é"** - Para pessoas com daltonismo, educadores e curiosos. Científico, inclusivo, elegante.

**3 Personality Adjectives:** Acessível, Elegante, Educativo

### Brand Voice
- **Headlines:** Diretas, informativas, sem jargão desnecessário
- **CTAs:** "Clique e veja", "Explore a visão", "Descubra como"
- **Microcopy:** Explicativo mas conciso

**Exemplos:**
- "Daltonismo não é ver em preto e branco. É ver cores de forma diferente."
- "Clique para ver como esta paleta aparece para pessoas com daltonismo."

### Wordmark & Logo
**Logo:** Um símbolo de 3 círculos sobrepostos em cores diferentes (vermelho, verde, azul) com um ícone de olho no centro. Representa a tríade cromática e a visão. Sem texto, apenas o símbolo.

### Signature Brand Color
**Azul-Acinzentado (#2C3E50)** - Neutro, confiável, acessível para a maioria dos tipos de daltonismo.

---

## Style Decisions

### Fontes
- **Display:** Poppins (Google Fonts)
- **Body:** Inter (Google Fonts)

### Espaçamento Base
- Unidade: 8px
- Padding padrão: 16px, 24px, 32px
- Margin padrão: 16px, 24px, 32px

### Sombras
- Suave: `0 1px 3px rgba(0,0,0,0.1)`
- Média: `0 4px 6px rgba(0,0,0,0.1)`
- Forte: `0 10px 15px rgba(0,0,0,0.1)`

### Border Radius
- Pequeno: 4px
- Médio: 8px
- Grande: 12px

### Transições
- Padrão: 300ms ease-out
- Rápida: 150ms ease-out
- Lenta: 500ms ease-out
