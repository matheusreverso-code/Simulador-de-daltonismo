import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Eye, Info } from "lucide-react";

interface ColorBlindnessType {
  id: string;
  name: string;
  description: string;
  prevalence: string;
  filterId: string;
}

function BrandMark() {
  return (
    <svg className="brand-mark" viewBox="0 0 48 48" role="img" aria-label="Marca do Simulador de Daltonismo">
      <circle cx="24" cy="14" r="10" fill="#E8756B" />
      <circle cx="14" cy="30" r="10" fill="#6B8E7F" />
      <circle cx="34" cy="30" r="10" fill="#315A86" />
      <circle cx="24" cy="24" r="7" fill="#F5F7FA" />
      <circle cx="24" cy="24" r="3" fill="#2C3E50" />
    </svg>
  );
}

const colorBlindnessTypes: ColorBlindnessType[] = [
  {
    id: "normal",
    name: "Visão Normal",
    description: "Como a maioria das pessoas enxerga as cores",
    prevalence: "99% da população",
    filterId: "normal",
  },
  {
    id: "protanopia",
    name: "Protanopia",
    description: "Deficiência de vermelho - dificuldade em diferenciar vermelho, verde e amarelo",
    prevalence: "1% dos homens",
    filterId: "protanopia",
  },
  {
    id: "deuteranopia",
    name: "Deuteranopia",
    description: "Deficiência de verde - afeta a percepção do verde",
    prevalence: "1% dos homens",
    filterId: "deuteranopia",
  },
  {
    id: "tritanopia",
    name: "Tritanopia",
    description: "Deficiência de azul - muito rara; afeta igualmente homens e mulheres",
    prevalence: "0.001% da população",
    filterId: "tritanopia",
  },
  {
    id: "achromatopsia",
    name: "Acromatopsia",
    description: "Monocromacia completa — visão em escala de cinza",
    prevalence: "0.00003% da população",
    filterId: "achromatopsia",
  },
  {
    id: "protanomaly",
    name: "Protanomalia",
    description: "Anomalia leve de vermelho — forma menos severa da Protanopia",
    prevalence: "0.6% dos homens",
    filterId: "protanomaly",
  },
  {
    id: "deuteranomaly",
    name: "Deuteranomalia",
    description: "Anomalia leve de verde — forma menos severa da Deuteranopia",
    prevalence: "0.4% dos homens",
    filterId: "deuteranomaly",
  },
  {
    id: "tritanomaly",
    name: "Tritanomalia",
    description: "Anomalia leve de azul — forma menos severa da Tritanopia",
    prevalence: "0.0001% da população",
    filterId: "tritanomaly",
  },
  {
    id: "achromatomaly",
    name: "Acromatomalia",
    description: "Monocromacia incompleta — forma leve de Acromatopsia",
    prevalence: "0.0001% da população",
    filterId: "achromatomaly",
  },
];

const testPalette = [
  { name: "Vermelho", hex: "#FF0000" },
  { name: "Verde", hex: "#00FF00" },
  { name: "Azul", hex: "#0000FF" },
  { name: "Amarelo", hex: "#FFFF00" },
  { name: "Magenta", hex: "#FF00FF" },
  { name: "Ciano", hex: "#00FFFF" },
  { name: "Laranja", hex: "#FFA500" },
  { name: "Rosa", hex: "#FFC0CB" },
];

export default function Home() {
  const [selectedType, setSelectedType] = useState<string>("normal");
  const [showSimulation, setShowSimulation] = useState<boolean>(false);

  const currentType = colorBlindnessTypes.find((t) => t.id === selectedType);

  const isSelected = (typeId: string) => selectedType === typeId;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* SVG Filters */}
      <svg style={{ height: 0, width: 0, padding: 0, margin: 0, lineHeight: 0 }}>
        <filter id="normal" colorInterpolationFilters="linearRGB">
          <feColorMatrix type="matrix" in="SourceGraphic" values="1,0,0,0,0 0,1,0,0,0 0,0,1,0,0 0,0,0,1,0" />
        </filter>
        <filter id="protanopia" colorInterpolationFilters="linearRGB">
          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            values="0.10889,0.89111,-0.00000,0,0 0.10889,0.89111,0.00000,0,0 0.00447,-0.00447,1.00000,0,0 0,0,0,1,0"
          />
        </filter>
        <filter id="deuteranopia" colorInterpolationFilters="linearRGB">
          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            values="0.29031,0.70969,-0.00000,0,0 0.29031,0.70969,-0.00000,0,0 -0.02197,0.02197,1.00000,0,0 0,0,0,1,0"
          />
        </filter>
        <filter id="tritanopia" colorInterpolationFilters="linearRGB">
          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            result="ProjectionOnPlane1"
            values="1.01354, 0.14268, -0.15622, 0, 0 -0.01181, 0.87561, 0.13619, 0, 0 0.07707, 0.81208, 0.11085, 0, 0 7.92482, -5.66475, -2.26007, 1, -0.2"
          />
        </filter>
        <filter id="achromatopsia" colorInterpolationFilters="linearRGB">\n          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            values="0.299, 0.587, 0.114, 0, 0 0.299, 0.587, 0.114, 0, 0 0.299, 0.587, 0.114, 0, 0 0, 0, 0, 1, 0"
          />
        </filter>
        <filter id="protanomaly" colorInterpolationFilters="linearRGB">
          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            values="0.817, 0.183, 0, 0, 0 0.333, 0.667, 0, 0, 0 0, 0.125, 0.875, 0, 0 0, 0, 0, 1, 0"
          />
        </filter>
        <filter id="deuteranomaly" colorInterpolationFilters="linearRGB">
          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            values="0.8, 0.2, 0, 0, 0 0.258, 0.742, 0, 0, 0 0, 0.142, 0.858, 0, 0 0, 0, 0, 1, 0"
          />
        </filter>
        <filter id="tritanomaly" colorInterpolationFilters="linearRGB">
          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            values="0.967, 0.033, 0, 0, 0 0, 0.733, 0.267, 0, 0 0, 0.183, 0.817, 0, 0 0, 0, 0, 1, 0"
          />
        </filter>
        <filter id="achromatomaly" colorInterpolationFilters="linearRGB">
          <feColorMatrix
            type="matrix"
            in="SourceGraphic"
            values="0.618, 0.320, 0.062, 0, 0 0.163, 0.775, 0.062, 0, 0 0.163, 0.320, 0.516, 0, 0 0, 0, 0, 1, 0"
          />
        </filter>
      </svg>

      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandMark />
            <h1 className="text-2xl font-bold text-primary">Simulador de Daltonismo</h1>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-12 md:py-20 overflow-hidden">
        <div className="hero-backdrop" aria-hidden="true" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h2 className="text-4xl md:text-5xl font-bold text-primary mb-4">Enxergue o Mundo Diferente</h2>
            <p className="text-lg text-gray-700 mb-6">
              Daltonismo não é ver em preto e branco. É ver cores de forma diferente. Explore como pessoas com
              deficiência visual cromática enxergam o mundo.
            </p>
            <div className="flex gap-4">
              <Button className="btn-primary" onClick={() => setShowSimulation(true)}>
                <Eye className="w-5 h-5 mr-2" />
                Começar a Explorar
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="container mx-auto px-4">
          {/* Type Selection */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-primary mb-8">Tipos de Daltonismo</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {colorBlindnessTypes.map((type) => {
                const selected = isSelected(type.id);
                const borderClass = selected ? "border-primary bg-blue-50 shadow-lg" : "border-gray-200 bg-white hover:border-primary hover:shadow-md";
                return (
                  <button
                    key={type.id}
                    onClick={() => {
                      setSelectedType(type.id);
                      setShowSimulation(false);
                    }}
                    className={`p-4 rounded-lg border-2 transition-all duration-300 text-left ${borderClass}`}
                  >
                    <h3 className="font-bold text-primary mb-2">{type.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">{type.description}</p>
                    <p className="text-xs text-gray-500 flex items-center gap-1">
                      <Info className="w-3 h-3" />
                      {type.prevalence}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Current Type Info */}
          {currentType && (
            <div className="card mb-12">
              <h3 className="text-2xl font-bold text-primary mb-4">{currentType.name}</h3>
              <p className="text-gray-700 mb-4">{currentType.description}</p>
              <p className="text-sm text-gray-600 mb-6">Prevalência: {currentType.prevalence}</p>
              <Button className="btn-primary" onClick={() => setShowSimulation(!showSimulation)}>
                {showSimulation ? "Voltar à Paleta Normal" : "Clique e Veja"}
              </Button>
            </div>
          )}

          {/* Color Palette */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-primary mb-6">Paleta de Cores</h3>

            {/* Normal Palette */}
            {!showSimulation && (
              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-700 mb-4">Visão Normal</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {testPalette.map((color) => (
                    <div key={color.hex} className="text-center">
                      <div
                        className="color-swatch mb-2"
                        style={{
                          backgroundColor: color.hex,
                        }}
                      />
                      <p className="font-semibold text-sm text-gray-700">{color.name}</p>
                      <p className="text-xs text-gray-500">{color.hex}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Simulated Palette */}
            {showSimulation && currentType && (
              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-700 mb-4">Como {currentType.name} enxerga</h4>
                <div
                  className="grid grid-cols-2 md:grid-cols-4 gap-4"
                  style={{
                    filter: `url(#${currentType.filterId})`,
                  }}
                >
                  {testPalette.map((color) => (
                    <div key={color.hex} className="text-center">
                      <div
                        className="color-swatch mb-2"
                        style={{
                          backgroundColor: color.hex,
                        }}
                      />
                      <p className="font-semibold text-sm text-gray-700">{color.name}</p>
                      <p className="text-xs text-gray-500">{color.hex}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Sobre Daltonismo</h4>
              <p className="text-sm opacity-90">
                Daltonismo é uma condição genética que afeta a percepção de cores. Afeta aproximadamente 1 em cada 12
                homens e 1 em cada 200 mulheres.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Tipos Comuns</h4>
              <ul className="text-sm opacity-90 space-y-2">
                <li>- Protanopia (deficiência de vermelho)</li>
                <li>- Deuteranopia (deficiência de verde)</li>
                <li>- Tritanopia (deficiência de azul)</li>
                <li>- Acromatopsia (sem cores)</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Recursos</h4>
              <ul className="text-sm opacity-90 space-y-2">
                <li>- Design acessivel para daltônicos</li>
                <li>- Testes de visão de cores</li>
                <li>- Ferramentas de simulação</li>
                <li>- Educação e conscientização</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-primary-foreground border-opacity-20 pt-8 text-center text-sm opacity-75">
            <p>&copy; 2026 Simulador de Daltonismo. Criado para educação e conscientização.</p>
            <p className="mt-2 font-semibold">Autoria: Matheus Reverso, Nathany e Kauan</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
